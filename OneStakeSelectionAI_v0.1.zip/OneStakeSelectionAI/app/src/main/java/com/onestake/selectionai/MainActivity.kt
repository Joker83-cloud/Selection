package com.onestake.selectionai

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = HistoryStore(this)
        setContent { MaterialTheme { OneStakeApp(store) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OneStakeApp(store: HistoryStore) {
    var tab by remember { mutableIntStateOf(0) }
    var apiKey by remember { mutableStateOf(store.apiKey()) }
    var history by remember { mutableStateOf(store.load()) }
    val tabs = listOf("ANALIZZA", "STORICO", "IMPOSTAZIONI")

    Scaffold(topBar = { TopAppBar(title = { Text("OneStake · Selection AI") }) }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            TabRow(selectedTabIndex = tab) {
                tabs.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
            }
            when (tab) {
                0 -> AnalyzeScreen(apiKey = apiKey, history = history, onSaved = { item ->
                    history = (history + item).takeLast(500)
                    store.save(history)
                })
                1 -> HistoryScreen(history = history, onChange = { updated -> history = updated; store.save(updated) })
                2 -> SettingsScreen(apiKey = apiKey, onApiKey = { apiKey = it; store.setApiKey(it) })
            }
        }
    }
}

@Composable
fun AnalyzeScreen(apiKey: String, history: List<MatchCandidate>, onSaved: (MatchCandidate) -> Unit) {
    var candidates by remember { mutableStateOf(emptyList<MatchCandidate>()) }
    var status by remember { mutableStateOf("Allega uno screenshot con squadre e quote 1-X-2.") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        busy = true
        status = "Lettura screenshot…"
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        runCatching { InputImage.fromFilePath(context, uri) }
            .onFailure { busy = false; status = "Immagine non leggibile: ${it.message}" }
            .onSuccess { image ->
                recognizer.process(image)
                    .addOnSuccessListener { text ->
                        candidates = OcrParser.parse(text.text)
                        status = if (candidates.isEmpty()) "Nessun match riconosciuto. Prova uno screenshot più nitido." else "${candidates.size} match riconosciuti. Controlla nomi e quote prima dell'analisi."
                        busy = false
                    }
                    .addOnFailureListener { e -> busy = false; status = "OCR fallito: ${e.message}" }
            }
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Button(onClick = { launcher.launch("image/*") }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
            Text(if (busy) "ELABORAZIONE…" else "📷 ALLEGA SCREENSHOT")
        }
        Spacer(Modifier.height(8.dp))
        Text(status, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            itemsIndexed(candidates, key = { _, it -> it.id }) { index, item ->
                CandidateCard(
                    item = item,
                    apiEnabled = apiKey.isNotBlank(),
                    onEdit = { changed -> candidates = candidates.toMutableList().also { it[index] = changed } },
                    onAnalyze = {
                        scope.launch {
                            busy = true
                            status = "Recupero classifica e forma per ${item.home}…"
                            val enriched = withContext(Dispatchers.IO) {
                                try {
                                    val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                                    ApiFootballClient(apiKey).enrich(item, date)
                                } catch (e: Exception) { item.copy(notes = "API: ${e.message}") }
                            }
                            val scored = AdaptiveCalibrator.calibrate(ScoringEngine.score(enriched), history)
                            candidates = candidates.toMutableList().also { it[index] = scored }
                            status = "Analisi completata."
                            busy = false
                        }
                    },
                    onSave = { onSaved(item) }
                )
            }
        }
    }
}

@Composable
fun CandidateCard(
    item: MatchCandidate,
    apiEnabled: Boolean,
    onEdit: (MatchCandidate) -> Unit,
    onAnalyze: () -> Unit,
    onSave: () -> Unit
) {
    var home by remember(item.id) { mutableStateOf(item.home) }
    var away by remember(item.id) { mutableStateOf(item.away) }
    var o1 by remember(item.id) { mutableStateOf(item.odd1.toString()) }
    var ox by remember(item.id) { mutableStateOf(item.oddX.toString()) }
    var o2 by remember(item.id) { mutableStateOf(item.odd2.toString()) }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            OutlinedTextField(home, { home = it; onEdit(item.copy(home = it)) }, label = { Text("Casa") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(away, { away = it; onEdit(item.copy(away = it)) }, label = { Text("Ospite") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OddsField("1", o1, Modifier.weight(1f)) { o1 = it; it.replace(',', '.').toDoubleOrNull()?.let { v -> onEdit(item.copy(odd1 = v)) } }
                OddsField("X", ox, Modifier.weight(1f)) { ox = it; it.replace(',', '.').toDoubleOrNull()?.let { v -> onEdit(item.copy(oddX = v)) } }
                OddsField("2", o2, Modifier.weight(1f)) { o2 = it; it.replace(',', '.').toDoubleOrNull()?.let { v -> onEdit(item.copy(odd2 = v)) } }
            }
            Spacer(Modifier.height(8.dp))
            if (item.verdict != Verdict.NEEDS_DATA) {
                Text("OneStake Score ${item.score}/100 · ${item.verdict}", fontWeight = FontWeight.Bold)
                Text("P reale ${(item.estimatedP * 100).fmt1()}% · Fair ${item.fairOdd.fmt2()} · EV ${(item.ev * 100).fmt1()}%")
                if (item.homeRank != null || item.awayRank != null) Text("Classifica: ${item.homeRank ?: "?"}ª vs ${item.awayRank ?: "?"}ª")
                if (item.homeFormPoints5 != null || item.awayFormPoints5 != null) Text("Punti ultime 5: ${item.homeFormPoints5 ?: "?"} vs ${item.awayFormPoints5 ?: "?"}")
            }
            if (item.notes.isNotBlank()) Text(item.notes, style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onAnalyze, enabled = apiEnabled, modifier = Modifier.weight(1f)) { Text(if (apiEnabled) "ANALIZZA" else "API KEY") }
                OutlinedButton(onClick = onSave, modifier = Modifier.weight(1f)) { Text("SALVA") }
            }
        }
    }
}

@Composable
fun OddsField(label: String, value: String, modifier: Modifier, onValue: (String) -> Unit) {
    OutlinedTextField(value = value, onValueChange = onValue, label = { Text(label) }, singleLine = true, modifier = modifier)
}

@Composable
fun HistoryScreen(history: List<MatchCandidate>, onChange: (List<MatchCandidate>) -> Unit) {
    val settled = history.filter { it.result != BetResult.PENDING }
    val won = settled.count { it.result == BetResult.WON }
    val staked = settled.size.toDouble()
    val profit = settled.sumOf { if (it.result == BetResult.WON) it.odd1 - 1.0 else -1.0 }
    val roi = if (staked == 0.0) 0.0 else profit / staked

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Casi: ${settled.size} · Vinte: $won · Win ${(if (settled.isEmpty()) 0.0 else won * 100.0 / settled.size).fmt1()}% · ROI ${(roi * 100).fmt1()}%", fontWeight = FontWeight.Bold)
        Text("Statistiche calcolate con stake virtuale 1 unità, separate dal motore stake OneStake.", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(history.reversed(), key = { _, it -> it.id }) { reverseIndex, item ->
                val realIndex = history.lastIndex - reverseIndex
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp)) {
                        Text("${item.home} – ${item.away} · 1 @${item.odd1.fmt2()}", fontWeight = FontWeight.Bold)
                        Text("Score ${item.score} · EV ${(item.ev * 100).fmt1()}% · ${item.verdict}")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { onChange(history.toMutableList().also { it[realIndex] = item.copy(result = BetResult.WON) }) }) { Text("VINTA") }
                            Button(onClick = { onChange(history.toMutableList().also { it[realIndex] = item.copy(result = BetResult.LOST) }) }) { Text("PERSA") }
                            OutlinedButton(onClick = { onChange(history.toMutableList().also { it[realIndex] = item.copy(result = BetResult.PENDING) }) }) { Text("PEND.") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(apiKey: String, onApiKey: (String) -> Unit) {
    var key by remember(apiKey) { mutableStateOf(apiKey) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Dati calcistici", fontWeight = FontWeight.Bold)
        Text("Inserisci la tua API key API-Football. Viene salvata solo sul dispositivo.", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(value = key, onValueChange = { key = it }, label = { Text("API-Football key") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Button(onClick = { onApiKey(key) }, modifier = Modifier.fillMaxWidth()) { Text("SALVA API KEY") }
        Spacer(Modifier.height(18.dp))
        Text("Regole v0.1", fontWeight = FontWeight.Bold)
        Text("• quota 1 target 1,50–2,10\n• classifica generale\n• rendimento casa/trasferta\n• punti ultime 5\n• probabilità 1X2 normalizzata per overround\n• EV >2% per PRUDENTE, >5% per FORTE\n• apprendimento automatico dei pesi NON ancora attivo: prima raccogliamo un campione pulito.")
    }
}

private fun Double.fmt1() = String.format(Locale.US, "%.1f", this)
private fun Double.fmt2() = String.format(Locale.US, "%.2f", this)
