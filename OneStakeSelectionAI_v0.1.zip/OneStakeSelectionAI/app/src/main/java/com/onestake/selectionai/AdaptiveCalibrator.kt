package com.onestake.selectionai

import kotlin.math.max
import kotlin.math.min

object AdaptiveCalibrator {
    /**
     * Controlled learning: use only settled historical matches with similar score and price.
     * Activation threshold: 20 comparable cases. Empirical win rate is shrunk toward the
     * base model with 30 pseudo-observations, preventing a small hot/cold streak from taking over.
     */
    fun calibrate(base: MatchCandidate, history: List<MatchCandidate>): MatchCandidate {
        val comparable = history.filter {
            it.result != BetResult.PENDING &&
            kotlin.math.abs(it.score - base.score) <= 10 &&
            kotlin.math.abs(it.odd1 - base.odd1) <= 0.20
        }
        if (comparable.size < 20) {
            return base.copy(notes = append(base.notes, "Apprendimento: ${comparable.size}/20 casi comparabili"))
        }
        val wins = comparable.count { it.result == BetResult.WON }
        val empirical = wins.toDouble() / comparable.size
        val pseudo = 30.0
        val blended = ((base.estimatedP * pseudo) + wins) / (pseudo + comparable.size)
        val p = min(0.85, max(0.20, blended))
        val ev = p * base.odd1 - 1.0
        val verdict = when {
            base.score >= 78 && ev > .05 -> Verdict.STRONG
            base.score >= 68 && ev > .02 -> Verdict.PRUDENT
            else -> Verdict.PASS
        }
        return base.copy(
            estimatedP = p,
            fairOdd = 1.0 / p,
            ev = ev,
            verdict = verdict,
            notes = append(base.notes, "Calibrato su ${comparable.size} casi: storico ${(empirical * 100).toInt()}%")
        )
    }

    private fun append(a: String, b: String) = if (a.isBlank()) b else "$a · $b"
}
