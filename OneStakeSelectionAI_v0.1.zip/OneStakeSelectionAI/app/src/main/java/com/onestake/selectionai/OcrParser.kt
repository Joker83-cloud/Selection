package com.onestake.selectionai

object OcrParser {
    private val oddRegex = Regex("(?<!\\d)([1-9]\\d?[.,]\\d{1,2})(?!\\d)")
    private val timeRegex = Regex("^\\d{1,2}[:.]\\d{2}$")

    /**
     * Conservative parser for bookmaker screenshots.
     * It only emits a match when 3 plausible 1X2 odds are found close together.
     * Team names are inferred from the nearest non-odds lines above the odds row.
     */
    fun parse(text: String): List<MatchCandidate> {
        val lines = text.lines()
            .map { it.trim().replace('–', '-').replace('—', '-') }
            .filter { it.isNotBlank() }

        val out = mutableListOf<MatchCandidate>()
        for (i in lines.indices) {
            val odds = oddRegex.findAll(lines[i]).mapNotNull { m ->
                m.groupValues[1].replace(',', '.').toDoubleOrNull()
            }.filter { it in 1.01..25.0 }.toList()

            if (odds.size >= 3) {
                val names = mutableListOf<String>()
                var j = i - 1
                while (j >= 0 && names.size < 2) {
                    val s = lines[j]
                    val hasOdd = oddRegex.containsMatchIn(s)
                    if (!hasOdd && !timeRegex.matches(s) && s.length >= 2 && s.none { it == '%' }) {
                        names.add(s)
                    }
                    j--
                }
                if (names.size == 2) {
                    val away = cleanTeam(names[0])
                    val home = cleanTeam(names[1])
                    if (home.isNotBlank() && away.isNotBlank()) {
                        out += MatchCandidate(home = home, away = away, odd1 = odds[0], oddX = odds[1], odd2 = odds[2])
                    }
                }
            }
        }
        return out.distinctBy { "${it.home.lowercase()}|${it.away.lowercase()}|${it.odd1}" }
    }

    private fun cleanTeam(s: String): String = s
        .replace(Regex("^[^A-Za-zÀ-ÿ0-9]+"), "")
        .replace(Regex("\\s+"), " ")
        .trim()
}
