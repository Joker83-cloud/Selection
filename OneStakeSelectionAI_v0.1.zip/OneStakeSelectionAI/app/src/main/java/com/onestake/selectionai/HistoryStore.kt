package com.onestake.selectionai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class HistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("onestake_selection_ai", Context.MODE_PRIVATE)

    fun apiKey(): String = prefs.getString("api_key", "") ?: ""
    fun setApiKey(value: String) = prefs.edit().putString("api_key", value.trim()).apply()

    fun load(): List<MatchCandidate> {
        val raw = prefs.getString("history", "[]") ?: "[]"
        val arr = JSONArray(raw)
        return buildList {
            for (i in 0 until arr.length()) add(fromJson(arr.getJSONObject(i)))
        }
    }

    fun save(items: List<MatchCandidate>) {
        val arr = JSONArray()
        items.takeLast(500).forEach { arr.put(toJson(it)) }
        prefs.edit().putString("history", arr.toString()).apply()
    }

    private fun toJson(m: MatchCandidate) = JSONObject().apply {
        put("id", m.id); put("home", m.home); put("away", m.away)
        put("odd1", m.odd1); put("oddX", m.oddX); put("odd2", m.odd2)
        put("score", m.score); put("p", m.estimatedP); put("fair", m.fairOdd); put("ev", m.ev)
        put("verdict", m.verdict.name); put("result", m.result.name); put("notes", m.notes)
        put("leagueName", m.leagueName ?: JSONObject.NULL)
        put("homeRank", m.homeRank ?: JSONObject.NULL); put("awayRank", m.awayRank ?: JSONObject.NULL)
        put("homeFormPoints5", m.homeFormPoints5 ?: JSONObject.NULL); put("awayFormPoints5", m.awayFormPoints5 ?: JSONObject.NULL)
        put("homeHomeWinRate", m.homeHomeWinRate ?: JSONObject.NULL); put("awayAwayLossRate", m.awayAwayLossRate ?: JSONObject.NULL)
    }

    private fun fromJson(o: JSONObject) = MatchCandidate(
        id = o.optLong("id", System.nanoTime()), home = o.optString("home"), away = o.optString("away"),
        odd1 = o.optDouble("odd1"), oddX = o.optDouble("oddX"), odd2 = o.optDouble("odd2"),
        leagueName = o.optString("leagueName").takeIf { it.isNotBlank() && it != "null" },
        homeRank = o.optInt("homeRank").takeIf { !o.isNull("homeRank") },
        awayRank = o.optInt("awayRank").takeIf { !o.isNull("awayRank") },
        homeFormPoints5 = o.optInt("homeFormPoints5").takeIf { !o.isNull("homeFormPoints5") },
        awayFormPoints5 = o.optInt("awayFormPoints5").takeIf { !o.isNull("awayFormPoints5") },
        homeHomeWinRate = o.optDouble("homeHomeWinRate").takeIf { !o.isNull("homeHomeWinRate") },
        awayAwayLossRate = o.optDouble("awayAwayLossRate").takeIf { !o.isNull("awayAwayLossRate") },
        score = o.optInt("score"), estimatedP = o.optDouble("p"), fairOdd = o.optDouble("fair"), ev = o.optDouble("ev"),
        verdict = runCatching { Verdict.valueOf(o.optString("verdict")) }.getOrDefault(Verdict.NEEDS_DATA),
        result = runCatching { BetResult.valueOf(o.optString("result")) }.getOrDefault(BetResult.PENDING),
        notes = o.optString("notes")
    )
}
