package com.onestake.selectionai

data class MatchCandidate(
    val id: Long = System.nanoTime(),
    val home: String,
    val away: String,
    val odd1: Double,
    val oddX: Double,
    val odd2: Double,
    val fixtureId: Int? = null,
    val leagueId: Int? = null,
    val leagueName: String? = null,
    val season: Int? = null,
    val homeTeamId: Int? = null,
    val awayTeamId: Int? = null,
    val homeRank: Int? = null,
    val awayRank: Int? = null,
    val homeFormPoints5: Int? = null,
    val awayFormPoints5: Int? = null,
    val homeHomeWinRate: Double? = null,
    val awayAwayLossRate: Double? = null,
    val score: Int = 0,
    val estimatedP: Double = 0.0,
    val fairOdd: Double = 0.0,
    val ev: Double = 0.0,
    val verdict: Verdict = Verdict.NEEDS_DATA,
    val result: BetResult = BetResult.PENDING,
    val notes: String = ""
)

enum class Verdict { STRONG, PRUDENT, PASS, NEEDS_DATA }
enum class BetResult { PENDING, WON, LOST }

data class ModelStats(
    val total: Int = 0,
    val won: Int = 0,
    val lost: Int = 0,
    val staked: Double = 0.0,
    val profit: Double = 0.0
) {
    val winRate: Double get() = if (total == 0) 0.0 else won.toDouble() / total
    val roi: Double get() = if (staked == 0.0) 0.0 else profit / staked
}
