package com.onestake.selectionai

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.Normalizer
import kotlin.math.max

class ApiFootballClient(private val apiKey: String) {
    private val base = "https://v3.football.api-sports.io"

    fun enrich(candidate: MatchCandidate, date: String): MatchCandidate {
        if (apiKey.isBlank()) return candidate.copy(notes = "Inserisci API key per arricchire i dati")
        val fixture = findFixture(candidate, date) ?: return candidate.copy(notes = "Match non trovato via API")

        val leagueId = fixture.getJSONObject("league").getInt("id")
        val season = fixture.getJSONObject("league").getInt("season")
        val teams = fixture.getJSONObject("teams")
        val homeObj = teams.getJSONObject("home")
        val awayObj = teams.getJSONObject("away")
        val homeId = homeObj.getInt("id")
        val awayId = awayObj.getInt("id")

        val standings = get("/standings?league=$leagueId&season=$season")
        val table = standings.optJSONArray("response")
            ?.optJSONObject(0)
            ?.optJSONObject("league")
            ?.optJSONArray("standings")
            ?.optJSONArray(0)

        var homeRank: Int? = null
        var awayRank: Int? = null
        var homeHomeWinRate: Double? = null
        var awayAwayLossRate: Double? = null

        if (table != null) {
            for (i in 0 until table.length()) {
                val row = table.getJSONObject(i)
                val teamId = row.getJSONObject("team").getInt("id")
                if (teamId == homeId) {
                    homeRank = row.optInt("rank").takeIf { it > 0 }
                    val home = row.optJSONObject("home")
                    val played = home?.optInt("played") ?: 0
                    val wins = home?.optInt("win") ?: 0
                    if (played > 0) homeHomeWinRate = wins.toDouble() / played
                }
                if (teamId == awayId) {
                    awayRank = row.optInt("rank").takeIf { it > 0 }
                    val away = row.optJSONObject("away")
                    val played = away?.optInt("played") ?: 0
                    val losses = away?.optInt("lose") ?: 0
                    if (played > 0) awayAwayLossRate = losses.toDouble() / played
                }
            }
        }

        val homePts5 = recentPoints(homeId)
        val awayPts5 = recentPoints(awayId)

        return candidate.copy(
            fixtureId = fixture.getJSONObject("fixture").getInt("id"),
            leagueId = leagueId,
            leagueName = fixture.getJSONObject("league").optString("name"),
            season = season,
            homeTeamId = homeId,
            awayTeamId = awayId,
            homeRank = homeRank,
            awayRank = awayRank,
            homeFormPoints5 = homePts5,
            awayFormPoints5 = awayPts5,
            homeHomeWinRate = homeHomeWinRate,
            awayAwayLossRate = awayAwayLossRate
        )
    }

    private fun recentPoints(teamId: Int): Int? {
        val data = get("/fixtures?team=$teamId&last=5&status=FT")
        val arr = data.optJSONArray("response") ?: return null
        if (arr.length() == 0) return null
        var pts = 0
        for (i in 0 until arr.length()) {
            val f = arr.getJSONObject(i)
            val teams = f.getJSONObject("teams")
            val home = teams.getJSONObject("home")
            val away = teams.getJSONObject("away")
            val isHome = home.getInt("id") == teamId
            val meWinner = if (isHome) home.opt("winner") else away.opt("winner")
            val otherWinner = if (isHome) away.opt("winner") else home.opt("winner")
            pts += when {
                meWinner == true -> 3
                otherWinner == true -> 0
                else -> 1
            }
        }
        return pts
    }

    private fun findFixture(c: MatchCandidate, date: String): JSONObject? {
        val encodedDate = URLEncoder.encode(date, "UTF-8")
        val data = get("/fixtures?date=$encodedDate")
        val arr = data.optJSONArray("response") ?: return null
        var best: JSONObject? = null
        var bestScore = 0.0
        for (i in 0 until arr.length()) {
            val f = arr.getJSONObject(i)
            val teams = f.getJSONObject("teams")
            val h = teams.getJSONObject("home").getString("name")
            val a = teams.getJSONObject("away").getString("name")
            val score = (similarity(c.home, h) + similarity(c.away, a)) / 2.0
            if (score > bestScore) { bestScore = score; best = f }
        }
        return if (bestScore >= 0.58) best else null
    }

    private fun similarity(a: String, b: String): Double {
        val x = normalize(a); val y = normalize(b)
        if (x == y) return 1.0
        if (x.contains(y) || y.contains(x)) return 0.9
        val ax = x.split(' ').filter { it.length > 2 }.toSet()
        val by = y.split(' ').filter { it.length > 2 }.toSet()
        if (ax.isEmpty() || by.isEmpty()) return 0.0
        return ax.intersect(by).size.toDouble() / max(ax.size, by.size)
    }

    private fun normalize(s: String): String = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .replace(Regex("[^a-z0-9 ]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun get(path: String): JSONObject {
        val conn = URL(base + path).openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.connectTimeout = 12000
        conn.readTimeout = 12000
        conn.setRequestProperty("x-apisports-key", apiKey)
        conn.setRequestProperty("Accept", "application/json")
        return try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("API HTTP $code: ${body.take(200)}")
            JSONObject(body)
        } finally { conn.disconnect() }
    }
}
