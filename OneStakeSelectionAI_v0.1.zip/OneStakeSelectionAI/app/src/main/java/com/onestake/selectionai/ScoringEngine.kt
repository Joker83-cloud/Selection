package com.onestake.selectionai

import kotlin.math.max
import kotlin.math.min

object ScoringEngine {
    fun score(m: MatchCandidate): MatchCandidate {
        val impliedRaw = 1.0 / m.odd1
        val overround = (1.0 / m.odd1) + (1.0 / m.oddX) + (1.0 / m.odd2)
        val marketP = impliedRaw / overround

        var pts = 0
        val reasons = mutableListOf<String>()

        // Quote: core OneStake range.
        when (m.odd1) {
            in 1.50..1.90 -> { pts += 24; reasons += "quota target" }
            in 1.91..2.10 -> { pts += 18; reasons += "quota accettabile" }
            in 2.11..2.50 -> pts += 8
            else -> return m.copy(score = 0, estimatedP = marketP, fairOdd = 1 / marketP, ev = 0.0, verdict = Verdict.PASS, notes = "Quota 1 fuori range OneStake")
        }

        if (m.homeRank != null && m.awayRank != null) {
            if (m.homeRank < m.awayRank) { pts += 18; reasons += "casa avanti in classifica" }
            else if (m.homeRank > m.awayRank) { pts += 6; reasons += "casa dietro: pattern rimbalzo da testare" }
        }

        if (m.homeHomeWinRate != null) {
            when {
                m.homeHomeWinRate >= .65 -> { pts += 18; reasons += "forte rendimento casa" }
                m.homeHomeWinRate >= .50 -> pts += 12
                m.homeHomeWinRate >= .35 -> pts += 5
            }
        }

        if (m.awayAwayLossRate != null) {
            when {
                m.awayAwayLossRate >= .60 -> { pts += 14; reasons += "ospite fragile fuori" }
                m.awayAwayLossRate >= .45 -> pts += 9
                m.awayAwayLossRate >= .30 -> pts += 4
            }
        }

        if (m.homeFormPoints5 != null && m.awayFormPoints5 != null) {
            val diff = m.homeFormPoints5 - m.awayFormPoints5
            if (diff >= 4) { pts += 12; reasons += "forma recente casa superiore" }
            else if (diff in -5..-1) { pts += 7; reasons += "casa dietro ultime 5: pattern test" }
            else if (diff >= 0) pts += 5
        }

        // Convert score into a conservative probability adjustment over normalized market probability.
        // Capped to avoid fake certainty; intended to be recalibrated from real outcomes later.
        val adjustment = ((pts - 50) / 1000.0).coerceIn(-0.04, 0.07)
        val p = min(0.82, max(0.25, marketP + adjustment))
        val ev = (p * m.odd1) - 1.0
        val fair = 1.0 / p
        val verdict = when {
            pts >= 78 && ev > .05 -> Verdict.STRONG
            pts >= 68 && ev > .02 -> Verdict.PRUDENT
            else -> Verdict.PASS
        }
        return m.copy(score = pts.coerceAtMost(100), estimatedP = p, fairOdd = fair, ev = ev, verdict = verdict, notes = reasons.joinToString(" · "))
    }
}
