# OneStake · Selection AI v0.1

Prototipo Android per affiancare OneStake nella selezione delle partite.

## Cosa fa già

1. Importa uno screenshot dalla galleria.
2. Esegue OCR on-device con Google ML Kit.
3. Cerca blocchi con 3 quote 1-X-2 e ricostruisce casa/ospite.
4. Permette di correggere manualmente nomi e quote riconosciuti.
5. Con una API key API-Football recupera:
   - match/competizione del giorno;
   - classifica generale;
   - rendimento casa della squadra di casa;
   - rendimento trasferta dell'ospite;
   - punti delle ultime 5 partite di entrambe.
6. Normalizza la probabilità implicita eliminando l'overround 1X2.
7. Calcola OneStake Score, probabilità stimata, fair odd ed EV.
8. Classifica la partita come STRONG / PRUDENT / PASS.
9. Salva lo storico e consente di registrare VINTA / PERSA / PENDENTE.
10. Mostra Win Rate e ROI con stake virtuale di 1 unità, separato dal motore stake OneStake.
11. Apprendimento controllato: dopo almeno 20 casi comparabili usa una calibrazione statistica con shrinkage, senza inseguire poche vittorie/sconfitte.

## Regole iniziali v0.1

- Quota 1 target: 1,50–2,10; 2,11–2,50 penalizzata; fuori 1,50–2,50 = PASS.
- Casa favorita bookmaker.
- Classifica generale.
- Rendimento casa/trasferta.
- Punti ultime 5.
- EV minimo +2% per PRUDENT, +5% per STRONG.
- Nessun peso viene modificato automaticamente finché non esistono almeno 20 casi comparabili.

## API-Football

La chiave NON è inclusa nel progetto. Nell'app aprire `IMPOSTAZIONI`, incollare la propria API key e salvarla. La chiave è memorizzata localmente tramite SharedPreferences.

Endpoint usati:
- `/fixtures?date=YYYY-MM-DD`
- `/standings?league=...&season=...`
- `/fixtures?team=...&last=5&status=FT`

## Importante

Questa è una v0.1 sperimentale. Il punteggio iniziale serve per raccogliere dati in modo coerente; non va considerato già validato statisticamente. Il vantaggio reale va misurato su un campione sufficientemente grande tramite ROI e calibrazione delle probabilità.

## Come aprire

Aprire la cartella `OneStakeSelectionAI` con Android Studio, attendere il Gradle Sync e avviare su dispositivo Android API 23+.

## Prossimi step consigliati

- Migliorare parser per lo specifico layout del bookmaker usato dall'utente.
- Recupero automatico del risultato finale via fixture ID.
- Aggiungere assenze/infortuni e statistiche avanzate quando disponibili.
- Dashboard pattern con ROI per requisito.
- Integrazione diretta con il motore stake OneStake esistente.
- Migrazione dati dell'attuale OneStake, evitando di perdere storico e bankroll.
